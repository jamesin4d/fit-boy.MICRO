# voidGazer.MICRO
## Description
Modeled after a clock face for Fitbit Sense, that was modeled after the legendary Pip-Boy from the Fallout Series by Fallout Series by Bethesda. 
Built using the Fitbit Studio and Fitbit Versa 3.

Welcome... to Void exploration.

## Target Devices
- Fitbit Sense
- Fitbit Versa 3

## Features
- Void guy with universe simulating goggles
- You may type in your name to signify that you're the owner/user 

### Clock
- Supports both 12-hour and 24-hour format

### Date and Day Format
- DDD YYYY-MM-DD
    
### Stats
- Distance in kilometers
- Active zone in minutes
- Calories burn in kcal
- Elevation in floors
- pedometer steps 
- Heart rate in bpm
- Resting heart rate in the bottom left-hand corner, marked as RHR
- Weight in the bottom right-hand corner, in LBS
- daily activity goal progress bar

### Color Schemes
- Lots of colors

### "Console"
- Displays "> CHARGING ..." when charging
- Displays "> USER NOT DETECTED" when not on wrist

- Greets you
- Has that cool flashing cursor terminals have
    
### WIP
- [x] Customizable name
- [x] More color schemes
- [x] Even more color schemes
- [x] Fix black screen on first run (no default color selected)
- [x] Add monofonto font
- [x] 12-hour format
- [x] 24-hour format
- [ ] Translations -- probably need to be redone.
- [x] Use the bottom bar as total progress
- [ ] ~~Potentially:  GPS~~ Rejected: Battery Saving
    - [ ] ~~Latitude~~
    - [ ] ~~Longitude~~
    - [ ] ~~Heading~~
- [ ] Make the voidGazer animated
- [ ] Potentially:  Time till sunrise / sunset


## Build Through CLI

0. Run `npm install`
1. run [Fitbit Simulator](https://simulator-updates.fitbit.com/download/latest/win)
2. Log into CLI `npx fitbit`
  - CLI should now display `fitbit$`
3. Build and Install  `fitbit$ bi`
  - The simulator should now display the clock face
  - The resulting built file is /build/app.fba