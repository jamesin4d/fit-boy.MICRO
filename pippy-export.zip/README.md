# Fit-Boy.MICRO
## Description
Modeled after a clock face for Fitbit Sense, that was modeled after the legendary Pip-Boy from the Fallout Series by Fallout Series by Bethesda. 
Built using the Fitbit Studio and Fitbit Versa 3.

Welcome... to Void exploration.

## Target Devices
- Fitbit Sense
- Fitbit Versa 3

## Features
- Void guy with universe simulating goggles
- You may type in your name to signify that you own this Fit-Boy

### Clock
- Supports both 12-hour and 24-hour format

### Date and Day Format
- DDD YYYY-MM-DD
    
### Stats
- Distance in kilometers
- Active zone in minutes
- Calories burn in kcal
- Elevation in floors
- Steps in... well... steps
- Heart rate in bpm
- Resting heart rate in the bottom left-hand corner, marked as HP
- Weight in the bottom right-hand corner, in kilograms
- Battery charge displayed instead of the LEVEL progress bar

### Color Schemes
- (#16FF42)
- (#FFB641)
- (#1AFF80)
- Lots of colors

### "Console"
- Displays "> CHARGING ..." when charging
- Displays "> USER NOT DETECTED" when not on wrist
  - Also hides the boy and name
- Greets you
- Has that cool flashing cursor terminals have
    
### WIP
- [x] Customizable name
- [x] More color schemes
- [x] Even more color schemes
- [x] Fix black screen on first run (no default color selected)
- [x] Add monofonto font
- [x] 12-hour format
- [x] 24-hour format
- [x] Translations
- [ ] ~~Potentially: Use the limb health bars as goal bars~~ Rejected: Battery Saving
  - [ ] ~~Active Zone Minutes~~
  - [ ] ~~Calories Burn~~
  - [ ] ~~Elevation~~
  - [ ] ~~Distance~~
  - [ ] ~~Steps~~
- [x] Use the bottom bar as total progress
- [ ] ~~Potentially:  GPS~~ Rejected: Battery Saving
    - [ ] ~~Latitude~~
    - [ ] ~~Longitude~~
    - [ ] ~~Heading~~
- [ ] Change picture based on the active zone and other factors
    - [ ] Make the vault boy animated
- [ ] Potentially:  Time till sunrise / sunset
- [ ] (Fitbit Permission Required) Always On Display

## Build Through CLI

0. Run `npm install`
1. run [Fitbit Simulator](https://simulator-updates.fitbit.com/download/latest/win)
2. Log into CLI `npx fitbit`
  - CLI should now display `fitbit$`
3. Build and Install  `fitbit$ bi`
  - The simulator should now display the clock face
  - The resulting built file is /build/app.fba