import { gettext } from "i18n";

function voidGazerSettings(props) {
  return (
    <Page>
      <Text bold align="center">{ gettext('appname') }</Text>
      <Section
        title={<Text bold>{ gettext('thm') }</Text>}>
        
        <ColorSelect
          label={ gettext('clr') }
          settingsKey="color"
          colors={[
            {color: "#f3c98d"},
            {color: "#FFB641"},
            {color: "#bb8d4d"},
            {color: "#ffffff"},
            {color: "#e28343"},
            {color: "#e68803"},
            {color: "#EC6173"},
            {color: "#c29e85"},
            {color: "#b78a6c"},
            {color: "#b7986c"},
            {color: "#c4af93"},
            {color: "#eec996"}         
          ]}
        />
        
        <Toggle
          settingsKey="cursor"
          label={ gettext('concurstop') }
          />
        
        <Slider
          settingsKey="bgop"
          min="0"
          max="100"
          label={ gettext('bgop') }
          />
        <Slider
          settingsKey="boyop"
          min="0"
          max="100"
          label={ gettext('boyop') }
          />
      </Section>
      <Section
        title={<Text bold>{ gettext('user') }</Text>}>
        
        <TextInput
          settingsKey="name"
          label={ gettext('nm') }
          />

        
      </Section>
    </Page>
  );
}

registerSettingsPage(voidGazerSettings);
